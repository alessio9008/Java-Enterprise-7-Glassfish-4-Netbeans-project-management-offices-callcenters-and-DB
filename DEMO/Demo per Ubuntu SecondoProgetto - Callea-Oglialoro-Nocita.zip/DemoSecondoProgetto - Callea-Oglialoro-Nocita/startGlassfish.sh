asadmin start-domain --verbose 
