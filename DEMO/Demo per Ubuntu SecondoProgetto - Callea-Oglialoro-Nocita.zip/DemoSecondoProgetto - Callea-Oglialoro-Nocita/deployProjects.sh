asadmin  deploy --force=true fileProjects/CentralinoWebServices1.war
asadmin  deploy --force=true fileProjects/CentralinoWebServices2.war
asadmin  deploy --force=true fileProjects/CentralinoWebServicesClient1.war
asadmin  deploy --force=true fileProjects/CentralinoWebServicesClient2.war
asadmin  deploy --force=true fileProjects/OfficeManager.jar 
asadmin  deploy --force=true fileProjects/Centralino.jar
asadmin  deploy --force=true fileProjects/DBReplicaManager.jar